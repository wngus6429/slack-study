export const onlineMap = {};
