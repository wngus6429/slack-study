import React from 'react';

const ChatList = () => {
  return <div>ChatList</div>;
};

export default ChatList;
